import React from 'react'

export default class Example3 extends React.Component {
   render() {
       return(
           <h1>Example 3</h1>
       )
   }
}