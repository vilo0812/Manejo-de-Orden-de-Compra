import React from 'react'

export default class Example2 extends React.Component {
   render() {
       return(
           <h1>Example 2</h1>
       )
   }
}